# Put your workshop notebooks here

Drop your `.ipynb` files in this folder. They'll appear in the deployed
JupyterLite site automatically on the next push.

Suggested naming so they sort in teaching order:

    01-beam-geometry.ipynb
    02-pulse-resolution.ipynb
    03-ambiguity.ipynb
    04-wavelength-scanning.ipynb

You can also drop in supporting data files (small CSVs, images) and they'll be
bundled into the site too. Keep data small — everything is downloaded to the
participant's browser.
